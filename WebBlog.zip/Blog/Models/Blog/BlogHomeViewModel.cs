﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlogPost.Models
{
    // View Model Created for Blog
    public class BlogHomeViewModel
    {
        public int Id { get; set; }
        public string Title { get; set; }

        public string Description { get; set; }

          public string Text { get; set; }
             public string Url { get; set; }


    }
}
