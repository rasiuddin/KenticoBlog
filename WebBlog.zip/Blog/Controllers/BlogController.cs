﻿using BlogPost.Models;
using BlogPost.Providers;
using CMS.DocumentEngine;
using Kentico.Content.Web.Mvc;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlogPost.Controllers
{
    public class BlogController:Controller
    {
        //public readonly Guid NodeGuid = Guid.Parse("1E38E9E2-CED9-49C8-AD5F-52A94446FF4E");
       
        private readonly IPageRetriever _pagesRetriever;
        private readonly IPageDataContextInitializer _pageDataContextInitializer;
        private readonly IPageDataContextRetriever _dataRetriever;

        private readonly ILogger<BlogController> _logger;

        public BlogController(ILogger<BlogController> logger, IPageRetriever pagesRetriever,
                                        IPageDataContextInitializer pageDataContextInitializer,
                                        IPageDataContextRetriever dataRetriever)
        {
            _logger = logger;
            _pageDataContextInitializer = pageDataContextInitializer;
            _pagesRetriever = pagesRetriever;
            _dataRetriever = dataRetriever;
        }
        // Created Home controleler
        public IActionResult Home()
        {

            TreeNode page = _pagesRetriever.Retrieve<TreeNode>(query => query
                                .Path("/Home", PathTypeEnum.Single))
                                .FirstOrDefault();

            if (page == null)
            {
                return NotFound();
            }
            _pageDataContextInitializer.Initialize(page);

            var homeSource = BlogProvider.GetBlogs();  // GetBlog(NodeGuid, "en-US", "Blog");
            var vm = new BlogHomeViewModel()
            {
                Id = homeSource.First().BlogID,
                Description = homeSource.First().Description,
                Title =  homeSource.First().Title,
                Text = homeSource.First().Text,
              // Url= homeSource.First().,
            };

            List<BlogHomeViewModel> list = new List<BlogHomeViewModel>();
            list.Add(vm);

            return View(list);


        }


        // Created About Us controleler
        public async Task<IActionResult> AboutUs()
        {
            return View();

        }
        // Created Contact Us controleler
        public async Task<IActionResult> ContactUs()
        {
            return View();

        }

        // Created Post controleler
        public async Task<IActionResult> Post()
        {
            return View();

        }
    }
}
